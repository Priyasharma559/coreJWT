﻿using Dapper;
using Microsoft.Data.SqlClient;
using RoleApp.Models;
using System.Data;
namespace RoleApp.Repository
{
    public interface IUserRepository
    {
        Task<User?> GetUserByUsername(string username);
    }
    public class UserRepository: IUserRepository
    {
        private readonly IConfiguration _config;
        public UserRepository(IConfiguration config) => _config = config;

        private IDbConnection CreateConnection() => new SqlConnection(_config.GetConnectionString("DefaultConnection"));

        public async Task<User?> GetUserByUsername(string username)
        {
            using var conn = CreateConnection();
            var result = await conn.QueryFirstOrDefaultAsync<User>(
                "sp_GetUserByUsername",
                new { Username = username },
                commandType: System.Data.CommandType.StoredProcedure
            );
            return result;
        }
    }
}
