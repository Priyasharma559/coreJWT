﻿using Microsoft.AspNetCore.Mvc;
using RoleApp.Repository;
using RoleApp.Service;

namespace RoleApp.Controllers
{
    public class Auth : Controller
    {
       
            private readonly IUserRepository _userRepo;
            private readonly JwtService _jwtService;

            public Auth(IUserRepository userRepo, JwtService jwtService)
            {
                _userRepo = userRepo;
                _jwtService = jwtService;
            }
            public IActionResult Index()
            {
                return View();
            }

           [HttpGet]
            public IActionResult Login() => View();

             [HttpPost]
            public async Task<IActionResult> Login(LoginRequest request)
            {
                var user = await _userRepo.GetUserByUsername(request.Username);
                if (user == null)
                {
                    ViewBag.Error = "Invalid credentials";
                    return View();
                }

                var token = _jwtService.GenerateToken(user);
                HttpContext.Response.Cookies.Append("jwt", token, new CookieOptions { HttpOnly = true });
                return RedirectToAction("Index", "Home");
            }
            private bool VerifyPassword(string password, string storedHash)
            {
                using var sha256 = System.Security.Cryptography.SHA256.Create();
                var hashBytes = sha256.ComputeHash(System.Text.Encoding.UTF8.GetBytes(password));
                var hash = Convert.ToBase64String(hashBytes);
                return hash == storedHash;
            }
      
    }
    public class LoginRequest
    {
        public string Username { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}
