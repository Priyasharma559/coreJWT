﻿using Microsoft.AspNetCore.Mvc;

namespace RoleApp.Controllers
{
    public class UserController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }

}
